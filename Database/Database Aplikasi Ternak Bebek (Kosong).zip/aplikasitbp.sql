-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 12. Januari 2021 jam 14:55
-- Versi Server: 5.5.16
-- Versi PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `aplikasitbp`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id_customer` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `no_telp` varchar(15) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_customer`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data untuk tabel `customer`
--

INSERT INTO `customer` (`id_customer`, `nama`, `alamat`, `no_telp`, `email`, `keterangan`) VALUES
(1, 'Mbah Wiyono', 'Geneng, Kaliares, Wonoboyo', '0', '-', '-'),
(2, 'Heri "Prabu"', 'Perum Giri Asri Brumbung', '0', '-', '-'),
(3, 'Bu Misno "Pakan"', 'Bungkal, Ponorogo', '0', '-', '-'),
(4, 'Jamu "Raka Sehat"', 'Wonokarto depan garasi Agra Mas', '0', '-', '-'),
(5, 'NN', 'Tonggo Dewe', '0', '-', '-'),
(6, 'Giyatno', 'Celep, Sukoharjo', '081336026273', '-', '-'),
(7, 'Baskoro', 'Wonoboyo', '0', '-', '-'),
(8, 'Sri "Pokoh Kidul"', 'Pokoh Kidul', '0', '-', '-'),
(9, 'Inti Telur', 'Bauresan, Belakang Pasar Wonogiri', '0', '-', '-'),
(10, 'Bu Lis', 'Jatisrono', '0', '-', '-'),
(11, 'Pak Iskak', 'Semin, Pokoh Kidul', '0', '-', '-'),
(12, 'Reza', 'Bauresan, Giripurwo, Wonogiri (Barat SMK Pariwisata)', '081239777135', '-', '-'),
(13, 'Anton Pancuran', 'Pancuran, Selogiri', '0895363091743', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `det_produksi`
--

CREATE TABLE IF NOT EXISTS `det_produksi` (
  `id_detproduksi` int(11) NOT NULL AUTO_INCREMENT,
  `id_produksi` int(11) NOT NULL,
  `tgl_produksi` date NOT NULL,
  `jumlah_produksi` int(11) NOT NULL,
  `keterangan` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id_detproduksi`),
  KEY `id_produksi` (`id_produksi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `gj_karyawan`
--

CREATE TABLE IF NOT EXISTS `gj_karyawan` (
  `id_kry` int(11) NOT NULL AUTO_INCREMENT,
  `id_profit` int(11) NOT NULL,
  `nama_kry` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_hp` varchar(15) DEFAULT NULL,
  `usia` int(11) DEFAULT NULL,
  `gaji` int(11) NOT NULL,
  `tgl_gaji` date NOT NULL,
  `keterangan` varchar(300) NOT NULL,
  PRIMARY KEY (`id_kry`),
  KEY `id_profit` (`id_profit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `m_bibit`
--

CREATE TABLE IF NOT EXISTS `m_bibit` (
  `id_mbibit` int(11) NOT NULL AUTO_INCREMENT,
  `id_profit` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `populasi` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `tgl_bibit` date NOT NULL,
  `total_Mbibit` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_mbibit`),
  KEY `id_profit` (`id_profit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `m_kandang`
--

CREATE TABLE IF NOT EXISTS `m_kandang` (
  `id_mkandang` int(11) NOT NULL AUTO_INCREMENT,
  `id_profit` int(11) NOT NULL,
  `ket_barang` varchar(50) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `tgl_beli` date DEFAULT NULL,
  `keterangan` varchar(300) DEFAULT NULL,
  `total_Mkandang` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_mkandang`),
  KEY `id_profit` (`id_profit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `m_lain`
--

CREATE TABLE IF NOT EXISTS `m_lain` (
  `id_mlain` int(11) NOT NULL AUTO_INCREMENT,
  `id_profit` int(11) NOT NULL,
  `ket_barang` varchar(50) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `tgl_beli` date NOT NULL,
  `keterangan` varchar(300) DEFAULT NULL,
  `total_Mlain` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_mlain`),
  KEY `id_profit` (`id_profit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `m_pakan`
--

CREATE TABLE IF NOT EXISTS `m_pakan` (
  `id_mpakan` int(11) NOT NULL AUTO_INCREMENT,
  `id_profit` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `tgl_beli` date NOT NULL,
  `keterangan` varchar(300) DEFAULT NULL,
  `total_Mpakan` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_mpakan`),
  KEY `id_profit` (`id_profit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemasukkan_lain`
--

CREATE TABLE IF NOT EXISTS `pemasukkan_lain` (
  `id_pemasukkan` int(11) NOT NULL AUTO_INCREMENT,
  `id_profit` int(11) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `keterangan` varchar(300) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `total` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_pemasukkan`),
  KEY `id_profit` (`id_profit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan_telur`
--

CREATE TABLE IF NOT EXISTS `penjualan_telur` (
  `id_penjualan` int(11) NOT NULL AUTO_INCREMENT,
  `id_profit` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `tanggal_jual` date NOT NULL,
  `jml_telur` int(11) NOT NULL,
  `harga_perbtr` int(11) NOT NULL,
  `total_pjl` int(11) DEFAULT NULL,
  `pembayaran` int(11) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_penjualan`),
  KEY `id_profit` (`id_profit`),
  KEY `id_customer` (`id_customer`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `produksi`
--

CREATE TABLE IF NOT EXISTS `produksi` (
  `id_produksi` int(11) NOT NULL AUTO_INCREMENT,
  `kandang` varchar(50) NOT NULL,
  `tgl_masuk_kandang` date NOT NULL,
  `total_produksi` int(11) DEFAULT NULL,
  `rata_produksi` int(11) DEFAULT NULL,
  `keterangan` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id_produksi`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `profit`
--

CREATE TABLE IF NOT EXISTS `profit` (
  `id_profit` int(11) NOT NULL AUTO_INCREMENT,
  `total_modalOut` int(11) DEFAULT NULL,
  `total_PenjualanTelur` int(11) DEFAULT NULL,
  `Keuntungan` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_profit`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `profit`
--

INSERT INTO `profit` (`id_profit`, `total_modalOut`, `total_PenjualanTelur`, `Keuntungan`) VALUES
(1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(10) NOT NULL,
  `hak_akses` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `hak_akses`) VALUES
(1, 'admin', 'admin', 0);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `det_produksi`
--
ALTER TABLE `det_produksi`
  ADD CONSTRAINT `det_produksi_ibfk_1` FOREIGN KEY (`id_produksi`) REFERENCES `produksi` (`id_produksi`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `gj_karyawan`
--
ALTER TABLE `gj_karyawan`
  ADD CONSTRAINT `gj_karyawan_ibfk_1` FOREIGN KEY (`id_profit`) REFERENCES `profit` (`id_profit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `m_bibit`
--
ALTER TABLE `m_bibit`
  ADD CONSTRAINT `m_bibit_ibfk_1` FOREIGN KEY (`id_profit`) REFERENCES `profit` (`id_profit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `m_kandang`
--
ALTER TABLE `m_kandang`
  ADD CONSTRAINT `m_kandang_ibfk_1` FOREIGN KEY (`id_profit`) REFERENCES `profit` (`id_profit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `m_lain`
--
ALTER TABLE `m_lain`
  ADD CONSTRAINT `m_lain_ibfk_1` FOREIGN KEY (`id_profit`) REFERENCES `profit` (`id_profit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `m_pakan`
--
ALTER TABLE `m_pakan`
  ADD CONSTRAINT `m_pakan_ibfk_1` FOREIGN KEY (`id_profit`) REFERENCES `profit` (`id_profit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pemasukkan_lain`
--
ALTER TABLE `pemasukkan_lain`
  ADD CONSTRAINT `pemasukkan_lain_ibfk_1` FOREIGN KEY (`id_profit`) REFERENCES `profit` (`id_profit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `penjualan_telur`
--
ALTER TABLE `penjualan_telur`
  ADD CONSTRAINT `penjualan_telur_ibfk_1` FOREIGN KEY (`id_profit`) REFERENCES `profit` (`id_profit`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `penjualan_telur_ibfk_2` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id_customer`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
